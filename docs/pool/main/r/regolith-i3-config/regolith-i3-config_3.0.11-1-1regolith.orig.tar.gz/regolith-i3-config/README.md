# regolith-i3-config

This repo is for Regolith-specific configuration for i3wm and variants.  