// vim:ts=4:sw=4:expandtab
#pragma once

void event_init(void);
